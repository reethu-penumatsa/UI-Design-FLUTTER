//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import desktop_window

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  DesktopWindowPlugin.register(with: registry.registrar(forPlugin: "DesktopWindowPlugin"))
}
