# Flutter Desktop/Web Spotify UI Tutorial

[YouTube Tutorial](https://youtu.be/HJ1AlSrgZVQ)

[Flutter Courses](https://launchclub.io)
