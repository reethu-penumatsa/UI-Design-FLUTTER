package com.example.flutter_spotify_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
